module.exports = async (client) => {
console.log(`- ${client.user.username} est connecter`)
}