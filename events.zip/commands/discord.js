const db = require('quick.db')
const Discord = require('discord.js')
module.exports = {
    name: 'discord',
    aliases: [],
    run: async (client, message, args, prefix) => {
message.reply(`**Discord pour acheté le Bot Custom **:\n\npas encore mdrrr`)
    }
}