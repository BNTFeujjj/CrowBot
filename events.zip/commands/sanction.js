const db = require('quick.db')
const Discord = require('discord.js')
module.exports = {
    name: 'sanction',
    aliases: [],
    run: async (client, message, args, prefix) => {
        return;
        }
    }